import logo from './logo.svg';
import './App.css';
import Sudoku from './containers/Sudoku'

function App() {
  return (
    <div className="App">
      <Sudoku/>
    </div>
  );
}

export default App;