# hw2_todolist_starter

[Reference video](https://youtu.be/Zf1PQAP9uuM)
